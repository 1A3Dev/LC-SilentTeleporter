# SilentTeleporter

## Information

This mod allows you to disable the teleport particles and sound effects.

## Changelog

### 1.0.0

- Initial Release
